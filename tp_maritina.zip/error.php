<?php
/** @var $this JDocumentHTML */
defined( '_JEXEC' ) or die( 'Restricted access' );
$this->_generator = '';
$baseUrl = JUri::base();
function renderModules( $position, $style = '' )
{
	$modules = JModuleHelper::getModules( $position );
	foreach ( $modules as $module ) {
		echo JModuleHelper::renderModule( $module, array( 'style' => $style ) );
	}
}

$this->params = JFactory::getApplication()->getTemplate( true )->params;
$template = JFactory::getApplication()->getTemplate();
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title><?php echo $this->error->getCode(); ?> - <?php echo htmlspecialchars( $this->error->getMessage() ); ?></title>
	<link rel="stylesheet" href="<?php echo $baseUrl; ?>templates/<?php echo $template; ?>/template_css.css?v9=9" type="text/css" />
	<script src="<?php echo $baseUrl; ?>media/jui/js/jquery.min.js" type="text/javascript"></script>
	<script src="<?php echo $baseUrl; ?>templates/'<?php echo $template; ?>'/scripts/site.js?v9=9" type="text/javascript"></script>
</head>
<body>
<div class="page relative">
	<div class="header relative">
		<a href="<?php echo $baseUrl; ?>" class="logo">Главная страница</a>
		<?php renderModules( 'header' ); ?>
	</div>
	<div class="mainbar relative">
		<div class="left-pane relative">
			<?php renderModules( 'left' ); ?>
		</div>
		<div class="content relative">
			<p class="size20">К сожалению, запрашиваемая Вами страница не найдена.</p>

			<div class="height-30"></div>
			<p class="size20">Мы приносим свои извинения за предоставленные неудобства и предлагаем следующие пути:</p>
			<ul>
				<li class="size20">перейти на главную <a href="http://2site.ru/" class="hover-u pink">страницу</a>;</li>
				<li class="size20">связаться с нами по телефону ;</li>
				<li class="size20"><a href="mailto:" class="hover-u pink">написать письмо</a> нам.</li>
			</ul>
		</div>
		<div class="clear  height-100"></div>
	</div>
</div>
<div class="footer relative">
	<?php renderModules( 'footer' ); ?>
</div>
</body>
</html>