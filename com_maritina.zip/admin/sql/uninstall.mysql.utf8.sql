DROP TABLE IF EXISTS `#__maritina_form`;
DROP TABLE IF EXISTS `#__maritina_refresh`;
